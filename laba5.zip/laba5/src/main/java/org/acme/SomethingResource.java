package org.acme;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/something")
public class SomethingResource {

    @GET
    @Path("/{a}")
    @Produces(MediaType.TEXT_PLAIN)
    public String somethingPath(@PathParam("a") String a) {
        return "something " + a;
    }

    //localhost:8080/something/101

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String something(@QueryParam("a") String a, @QueryParam("b") String b) {
        return "something a = " + a + " and b = " + b + " sum = " + a + b;
    }
}

//localhost:8080/something?a=108&b=11